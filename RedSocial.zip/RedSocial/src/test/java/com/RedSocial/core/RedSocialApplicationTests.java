package com.RedSocial.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedSocialApplicationTests {

	@Test
	void contextLoads() {
	}

}
