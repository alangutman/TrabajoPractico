package com.RedSocial.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedSocialApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedSocialApplication.class, args);
	}

}
